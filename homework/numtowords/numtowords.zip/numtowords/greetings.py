"""Pydocstyle wants a documentation here."""


def hello():
    """Pydocstyle wants a documentation here."""
    print("Hello!")
